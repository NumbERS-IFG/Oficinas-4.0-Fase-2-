import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import Login from '../components/login';

export default function Inicio() {
  return (
    <>
    <Login/>
    </>
  );
}

